#
# Cookbook:: node_site
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.

include_recipe 'node_site::site'