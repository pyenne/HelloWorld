# node-info

This cookbook is designed to write a new file to the home directory of a managed node, containing information taken from the node's Ohai profile.
