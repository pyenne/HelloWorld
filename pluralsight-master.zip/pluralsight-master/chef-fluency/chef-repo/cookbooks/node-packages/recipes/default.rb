#
# Cookbook:: node-packages
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.

include_recipe 'node-packages::packages'