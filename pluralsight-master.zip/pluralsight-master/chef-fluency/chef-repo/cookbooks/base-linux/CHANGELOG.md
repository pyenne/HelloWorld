# base-linux CHANGELOG

This file is used to list changes made in each version of the base-linux cookbook.

# 0.1.0

Initial release.

- change 0
- change 1

