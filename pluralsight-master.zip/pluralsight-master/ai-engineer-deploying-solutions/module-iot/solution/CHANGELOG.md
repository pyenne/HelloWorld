## Custom Vision + Azure IoT Edge on a Raspberry Pi 3 demo Changelog

<a name="1.0.0"></a>
# 1.0.0 release (2018-05-30)
First release

<a name="1.1.0"></a>
# 1.1.0 release (2018-07-20)
Second release to make it compatible with the Azure IoT EDge GA bits

# 1.2.0 releae (2018-08-31)
Enable image stream via WebSocket (instead of showing frames via X11 server)
