template '/tmp/node-info.txt' do
  source 'node-info.txt.erb'
end

# file '/tmp/node-info.txt' do
#  content node_info
#  mode '00755'
# end
