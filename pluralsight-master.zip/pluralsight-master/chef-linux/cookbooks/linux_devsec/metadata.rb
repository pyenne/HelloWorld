name 'linux_devsec'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'All Rights Reserved'
description 'Installs/Configures linux_devsec'
version '0.1.0'
chef_version '>= 15.0'

depends 'os-hardening'
