name 'windows_node'
maintainer 'James Bannan'
maintainer_email 'james@myemail.com'
license 'All Rights Reserved'
description 'Installs/Configures windows_node'
version '0.1.0'
chef_version '>= 15.0'

depends 'iis'
