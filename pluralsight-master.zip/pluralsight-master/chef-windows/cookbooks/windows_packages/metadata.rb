name 'windows_packages'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'All Rights Reserved'
description 'Installs/Configures windows_packages'
version '0.2.0'
chef_version '>= 15.0'

depends 'chocolatey', '~> 2.0.1'
